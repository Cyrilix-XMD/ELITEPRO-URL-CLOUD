//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6288989691060"] 
global.namabot = '—͟͞𝙉𝙤𝙠𝙪𝙯 𝙄𝙣𝙫𝙞𝙘𝙩𝙪𝙯'
//======================
global.mess = { 
owner: '*Khusus Owner cuy*',
premium: '*Khusus Premium cuy*',
succes: '*Done cuy*'
}
//=======================