// welcomeManager.js
import fetch from 'node-fetch';
import fs from 'fs';

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

class WelcomeManager {
    constructor(socket) {
        this.socket = socket;
        this.activeGroups = new Set();
        this.messageQueues = new Map();
        this.setupListeners();
    }

    // ==================== Gestion d'activation ====================
    async enableForGroup(jid) {
        if (this.isActive(jid)) {
            return false;
        }

        this.activeGroups.add(jid);
        this.initializeQueue(jid);
        return true;
    }

    async disableForGroup(jid) {
        this.activeGroups.delete(jid);
        this.clearQueue(jid);
        return true;
    }

    isActive(jid) {
        return this.activeGroups.has(jid);
    }

    // ==================== Gestion des queues ====================
    initializeQueue(jid) {
        if (!this.messageQueues.has(jid)) {
            this.messageQueues.set(jid, {
                queue: [],
                isProcessing: false
            });
        }
    }

    clearQueue(jid) {
        this.messageQueues.delete(jid);
    }

    async addToQueue(jid, task) {
        this.initializeQueue(jid);
        const groupQueue = this.messageQueues.get(jid);

        groupQueue.queue.push(task);
        if (!groupQueue.isProcessing) {
            this.processQueue(jid);
        }
    }

    async processQueue(jid) {
        const groupQueue = this.messageQueues.get(jid);
        if (!groupQueue) return;

        groupQueue.isProcessing = true;

        while (groupQueue.queue.length > 0 && this.isActive(jid)) {
            const task = groupQueue.queue.shift();
            try {
                await task();
                await delay(1000); // Délai entre messages
            } catch (error) {
                console.error(`[Queue Error] ${jid}:`, error);
            }
        }

        groupQueue.isProcessing = false;
    }

    // ==================== Gestion des événements ====================
    setupListeners() {
        this.socket.ev.on('group-participants.update', async (event) => {
            const { id, participants, action } = event;

            if (!this.isActive(id)) return;

            try {
                if (action === 'add') {
                    await this.handleNewMember(id, participants[0]);
                } else if (action === 'remove') {
                    await this.handleLeavingMember(id, participants[0]);
                }
            } catch (error) {
                console.error(`[Event Error] ${id}:`, error);
            }
        });
    }

    // ==================== Fonctions de message ====================
    async handleNewMember(jid, newMember) {
        console.log(`[Welcome] Nouveau membre dans ${jid}: ${newMember}`);
        await this.addToQueue(jid, async () => {
            try {
                const metadata = await this.getGroupMetadata(jid);
                const memberCount = metadata?.participants?.length || 0;
                const ppBuffer = await this.getProfilePicture(newMember);

                const message = this.createWelcomeMessage(newMember, metadata, memberCount);
                await this.sendWelcome(jid, newMember, message, ppBuffer);
            } catch (error) {
                console.error(`[Welcome Error] ${jid}:`, error);
                await this.sendFallbackWelcome(jid, newMember);
            }
        });
    }

    async handleLeavingMember(jid, leavingMember) {
        console.log(`[Goodbye] Membre parti de ${jid}: ${leavingMember}`);
        await this.addToQueue(jid, async () => {
            try {
                const metadata = await this.getGroupMetadata(jid);
                const memberCount =  metadata?.participants?.length || 0;
                const ppBuffer = await this.getProfilePicture(jid);
                const message = this.createGoodbyeMessage(leavingMember, memberCount);
                
            if (ppBuffer) {
                await this.socket.sendMessage(jid, {
                image: ppBuffer,
                caption: message,
                mentions: [leavingMember],
            })}else {
                await this.socket.sendMessage(jid, {
                    text: message,
                    mentions: [leavingMember]
                });
            }

            } catch (error) {
                console.error(`[Goodbye Error] ${jid}:`, error);
            }
        });
    }

    // ==================== Helpers ====================
    async getGroupMetadata(jid) {
        try {
            return await this.socket.groupMetadata(jid);
        } catch (error) {
            console.error(`[Metadata Error] ${jid}:`, error);
            return null;
        }
    }

    async getProfilePicture(jid) {
        try {
            const ppUrl = await this.socket.profilePictureUrl(jid, 'image');
            if (!ppUrl) return null;

            const response = await fetch(ppUrl);
            return Buffer.from(await response.arrayBuffer());
        } catch (error) {
            console.log(`[PP Error] ${jid}: Photo non disponible`);
            return null;
        }
    }

    createWelcomeMessage(newMember, metadata, memberCount) {
        const username = newMember.split('@')[0];
        const joinDate = new Date().toLocaleString('fr-FR', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            hour: '2-digit',
            minute: '2-digit'
        });

        return `
🌟 *BIENVENUE* @${username} ! 🌟

📅 Arrivé le : ${joinDate}
👥 Membres : ${memberCount}
📌 Groupe : ${metadata?.subject || 'Inconnu'}
📝 Description : ${metadata?.desc || 'Aucune description'}

Merci de lire les règles et de te présenter si tu le souhaites !
▬▬▬▬▬▬▬▬▬▬▬▬
💬 N'hésite pas à participer aux discussions et à partager tes idées !
▬▬▬▬▬▬▬▬▬▬▬▬

> powered by Vanscode
        `;
    }

    createGoodbyeMessage(leavingMember, memberCount) {
        const username = leavingMember.split('@')[0];
    const randomPhrases = [
        "On espère que c'est pas à cause de nos blagues pourries !",
        "Tu nous quittes pour TikTok, c'est ça ?",
        "Souviens-toi : ici c'était mieux que chez ta belle-mère !",
        "Attention, la porte est basse... enfin, moins que nos blagues !",
        "Emporte un cookie virtuel 🍪 en partant !"
    ];
    const randomIndex = Math.floor(Math.random() * randomPhrases.length);

    return `
😢 *A PLUS TARD* @${username}* ! 

▬▬▬▬▬▬▬▬▬▬▬▬
👥 Il reste ${memberCount} courageux membres
💬 ${randomPhrases[randomIndex]}
▬▬▬▬▬▬▬▬▬▬▬▬

PS : On a caché tes clés sous le paillasson virtuel 🔑

> powered by Vanscode
    `;
    }

    async sendWelcome(jid, newMember, message, ppBuffer) {
        if (ppBuffer) {
            await this.socket.sendMessage(jid, {
                image: ppBuffer,
                caption: message,
                mentions: [newMember],
    
               
            });
        } else {
            await this.socket.sendMessage(jid, {
                text: message,
                mentions: [newMember]
            });
        }
    }

    async sendFallbackWelcome(jid, newMember) {
        await this.socket.sendMessage(jid, {
            text: `Bienvenue @${newMember.split('@')[0]} dans le groupe ! 🎉`,
            mentions: [newMember]     
        });
    }
}

// Singleton pattern
let instance = null;

export function getWelcomeManager(socket) {
    if (!instance) {
        instance = new WelcomeManager(socket);
    }
    return instance;
}