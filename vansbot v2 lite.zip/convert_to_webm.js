import ffmpeg from 'fluent-ffmpeg';

ffmpeg('input.mp4')
  .outputOptions('-c:v', 'vp9', '-b:v', '0', '-crf', '40')
  .save('output.webm')
  .on('end', () => console.log('Conversion terminée !'));