function tempsEcriture(texte, mode) {
  const vitesses = {
    lent: 150 / 60,   // caractères par seconde
    moyen: 250 / 60,
    rapide: 450 / 60
  };

  // Vérifie que le mode est valide
  if (!vitesses[mode]) {
    throw new Error("Mode invalide. Utilisez 'lent', 'moyen' ou 'rapide'.");
  }

  const longueurTexte = texte.length;
  const vitesse = vitesses[mode];
  const tempsEnSecondes = longueurTexte / vitesse;

  return Math.round(tempsEnSecondes * 100) / 100; // arrondi à 2 décimales
}

export default tempsEcriture;