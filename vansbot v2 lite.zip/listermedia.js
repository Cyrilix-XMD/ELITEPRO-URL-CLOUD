import { readdir, stat } from 'fs/promises';

export async function listerMedias(dossier) {
  let dossierStat;

  try {
    dossierStat = await stat(dossier);
  } catch (err) {
    return null;
  }

  if (!dossierStat.isDirectory()) {
    return null;
  }

  const fichiers = await readdir(dossier);

  const medias = {
    images: [],
    videos: [],
    gifs: [],
    stickers: [],
    audios: [],
  };

  for (const fichier of fichiers) {
    if (fichier.endsWith('_image.jpg')) {
      medias.images.push(fichier.replace('_image.jpg', ''));
    } else if (fichier.endsWith('_video.mp4')) {
      medias.videos.push(fichier.replace('_video.mp4', ''));
    } else if (fichier.endsWith('_gif.mp4')) {
      medias.gifs.push(fichier.replace('_gif.mp4', ''));
    } else if (fichier.endsWith('_sticker.webp')) {
      medias.stickers.push(fichier.replace('_sticker.webp', ''));
    } else if (fichier.endsWith('_audio.ogg')) {
      medias.audios.push(fichier.replace('_audio.ogg', ''));
    }
  }

  for (const type in medias) {
    medias[type].sort();
  }

  let texte = '';

  if (medias.images.length > 0) {
    texte += `🖼️ Images:\n${medias.images.map((n, i) => `${i + 1}. ${n}`).join('\n')}\n\n`;
  }

  if (medias.videos.length > 0) {
    texte += `🎬 Vidéos:\n${medias.videos.map((n, i) => `${i + 1}. ${n}`).join('\n')}\n\n`;
  }

  if (medias.gifs.length > 0) {
    texte += `🎞️ GIFs:\n${medias.gifs.map((n, i) => `${i + 1}. ${n}`).join('\n')}\n\n`;
  }

  if (medias.stickers.length > 0) {
    texte += `💠 Stickers:\n${medias.stickers.map((n, i) => `${i + 1}. ${n}`).join('\n')}\n\n`;
  }

  if (medias.audios.length > 0) {
    texte += `🎧 Audios:\n${medias.audios.map((n, i) => `${i + 1}. ${n}`).join('\n')}\n\n`;
  }

  return texte.trim();
}
