export function stylizeText(text) {
  return text.replace(/[A-Za-z]/g, (char) => {
    const code = char.codePointAt(0);
    if (char >= 'A' && char <= 'Z') {
      return String.fromCodePoint(code + 0x1D400 - 0x41); // 'A' → 0x1D400
    } else if (char >= 'a' && char <= 'z') {
      return String.fromCodePoint(code + 0x1D41A - 0x61); // 'a' → 0x1D41A
    } else {
      return char;
    }
  });
}
