export function estNumeroTelephone(chaine) {
  const regex = /^(\+?\d{1,4})?[\s.-]?\(?\d{2,4}\)?[\s.-]?\d{2,4}[\s.-]?\d{2,4}[\s.-]?\d{0,4}$/;
  return regex.test(chaine);
}

