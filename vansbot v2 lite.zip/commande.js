import { join } from "path";
import {
    sendWhatsAppMessage,
    send_audio_message,
    send_contact_message,
    send_gif_message,
    send_image_message,
    send_location_message,
    send_reaction_message,
    send_text_message,

    send_video_message,
    chercherFichier,
    send_sticker_message,
} from "./sendmessagewa.js";
import sharp from 'sharp'
import { delay,jidNormalizedUser } from "@whiskeysockets/baileys";
import downloader_media from "./download_media.js";
import {
    listerPremierFichierTemporaire,
    supprimerFichierCommencantPar,
} from "./vu_unique.js";
import { convertToSticker } from "./convert_to_webp.js";
import { estNumeroTelephone } from "./estunnumerodetel.js";
import {
    isAdmin,
    banUser,
    addmember,
    promoteAdmin,
    demoteAdmin,
    muteGroup,
    unmuteGroup,
    getQuote,
} from "./gestion_groupe.js";
import dotenv from "dotenv";
import pino from "pino";
import { listerMedias } from "./listermedia.js";
import { info } from "console";
import  fs from 'fs';
import {getWelcomeManager} from "./welcomemanager.js";
import { analyserGroupeWhatsApp } from "./groupeinfo.js";



dotenv.config();
// Configuration
const logger = pino({
    level: "debug",
    transport: {
        target: "pino-pretty",
        options: {
            colorize: true,
            ignore: "pid,hostname", // Masque les infos inutiles
            translateTime: "HH:MM:ss", // Temps lisible
            includeStack: true, // ↓ Affiche les traces d'erreur
            errorLikeObjectKeys: ["err", "error"], // Capture les objets d'erreur
        },
    },
    base: null, // Désactive les métadonnées par défaut (pid, hostname)
});
const PREFIXE = process.env.PREFIXE ;
const MEDIA_PATH = "./whatsapp-media";
const AUTHORIZED_USERS = ["237652033289@s.whatsapp.net","237653937386@s.whatsapp.net","237696053118@s.whatsapp.net","237688436397q@s.whatsapp.net"];
let flag = true;
let date = new Date().toLocaleString("fr-FR", {
        timeZone: "Africa/Douala",
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    });

export async function handleCommand(
    socket,
    info_message_objet,
    jid,
    command,
    args,
    isGroup
) {
    let speudo = (await socket.user?.name) || "inconnue";
    const MENU_TEXT = `
🔰 〘 𝐕𝐀𝐍𝐒𝐁𝐎𝐓 〙


╭─🎖️ 𝐈𝐍𝐅𝐎 𝐁𝐎𝐓 ─╮
➤ 👑 Owner : 𝐕𝐀𝐍𝐒𝐂𝐎𝐃𝐄  
➤ 👤 User  : ${speudo}  
➤ 🔮 Version : 2  
➤ 🎨 Thème : 𝐋𝐔𝐅𝐅𝐘  
➤ 🌐 Langue : FR / EN  
➤ 🔗 Support-yt:@Vanstech-o6c
───────────────


📜𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 𝐆𝐄́𝐍𝐄́𝐑𝐀𝐋𝐄𝐒 

⚡ ${PREFIXE}ping  
⤷ Vérifie la latence

📅 ${PREFIXE}date  
⤷ Donne la date & l’heure

📞 ${PREFIXE}contact <num> <nom>  
⤷ Enregistre un contact [Beta]

🗺️ ${PREFIXE}loc <lat> <long> <nom>  
⤷ Partage une position [Beta]

🔎 ${PREFIXE}info <phone-number>  
⤷ Affiche les infos d’un utilisateur

🖼️ ${PREFIXE}setpp (répondre)  
⤷ Modifie la photo du groupe

🎭𝐌𝐄𝐃𝐈𝐀𝐒 & 𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒

👁️ ${PREFIXE}vu (répondre)  
⤷ devoile vu unique "vu"

🖼️ ${PREFIXE}img <nom>  
⤷ Envoie une image stockée

🎞️ ${PREFIXE}gif <nom>  
⤷ Envoie un GIF animé

🎬 ${PREFIXE}vid <nom>  
⤷ Envoie une vidéo

🔊 ${PREFIXE}aud <nom>  
⤷ Envoie un audio

✨ ${PREFIXE}stk <nom>  
⤷ Envoie Sticker personnalisé

🖌️ ${PREFIXE}tostk (répondre)  
⤷ Convertit une image en sticker


💾𝐆𝐄𝐒𝐓𝐈𝐎𝐍 𝐃𝐄 𝐌𝐄𝐃𝐈𝐀𝐒

💾 ${PREFIXE}store <nom> (répondre)  
⤷ Sauvegarde un média

📋 ${PREFIXE}list  
⤷ Liste tous les médias

🗑️ ${PREFIXE}del <nom>  
⤷ Supprime un média


👑 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 𝐀𝐃𝐌𝐈𝐍

🎉${PREFIXE}welcome 
⤷ souhaite bienvenu 

⬆️ ${PREFIXE}promote (@user)  
⤷ Donne rôle admin

⬆️ ${PREFIXE}promoteall
⤷ Donne rôle admin à tous

⬇️ ${PREFIXE}demote (@user)  
⤷ Retire rôle admin

⬇️ ${PREFIXE}demoteall
⤷ Retire rôle admin à tous

📢 ${PREFIXE}tagall [msg]  
⤷ Mentionne tous les membres

🚫 ${PREFIXE}ban (@user)  
⤷ Bannit un utilisateur

🚫 ${PREFIXE}banall  
⤷ Bannit tout le monde

🔇 ${PREFIXE}mute <secondes>  
⤷ Silence le groupe

🔊 ${PREFIXE}unmute  
⤷ Rétablit les messages

🔍 ${PREFIXE}isadmin (@user)
⤷ Vérifie si un utilisateur est admin

🕵️‍♂️${PREFIXE}groupinfo
⤷info du groupe 

╭─🎉 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 𝐅un ─╮

➤ ${PREFIXE}motivation
⤷video de motivation 


ℹ️ 𝐀𝐈𝐃𝐄 & 𝐈𝐍𝐅𝐎𝐒

❓ ${PREFIXE}help [catégorie]  
⤷ Affiche ce menu

📚 ${PREFIXE}doc  
⤷ Voir la documentation

ℹ️ ${PREFIXE}about  
⤷ Infos générales du bot

🔄 ${PREFIXE}updates  
⤷ Derniers ajouts


👑 𝐂𝐑𝐄́𝐃𝐈𝐓𝐒

🔧 Dev : @Vanstech-o6c  
💖 Contributeurs : AskDev, Senku, Shadow, Mika 
   ━━━━━━━━━━━━━━━━━━`;
    logger.debug(`Commande reçue: ${command} avec arguments: ${args.join(", ")}`);
    logger.debug(`JID du message: ${jid}, Est-ce un groupe? ${isGroup}`);
    speudo = (await socket.user?.name) || "inconnue";
    // --- Identifie le JID brut de l’expéditeur ---
    //    · Si message de groupe : info_message_objet.key.participant est défini
    //    · Si chat privé : info_message_objet.key.participant est undefined
    const rawSenderJid =
        info_message_objet.key?.participant || info_message_objet.key?.remoteJid;

    // --- Vérifie si l’expéditeur est dans la whitelist ---
    if (
        !info_message_objet.key.fromMe &&
        !AUTHORIZED_USERS.includes(rawSenderJid) &&
        !jid.includes("@g.us")
    ) {
        // Envoie un message « Accès non autorisé » dans le même chat (groupe ou privé)
        await send_reaction_message(socket, info_message_objet, jid, "😴");
        return; // Passe au message suivant
    }

     if (isGroup) {
                const myspeudo=socket.user?.name;
                if (!myspeudo) {
                  await send_text_message(
                    socket,
                    info_message_objet,
                    `> ⚠️ Veuillez définir un pseudo pour le bot dans les paramètres de WhatsApp pour vous identifier dans le groupe.${myspeudo}`,
                    jid,
                    undefined,
                    true
                  );
                  return;
                }else {
                  if (info_message_objet.pushName!==myspeudo) {
                  await send_reaction_message(socket,info_message_objet,jid,"😪")
                    return; 
                  }
                }
        }

    try {
        switch (command.toLowerCase()) {
            case "menu":
            case "help":
                /* await sendWhatsAppMessage(socket, jid, {
                             type: "image",
                             params: { source: "vansbot.jpg", caption: MENU_TEXT },
                         });*/
                await send_reaction_message(socket,info_message_objet,jid,"🧾")
                await send_gif_message(socket, info_message_objet, jid, "media-bot/vansbot.mp4",MENU_TEXT);
                await send_audio_message(socket, info_message_objet, jid, "media-bot/vansbot.mp3", undefined, false);
                break;
            case "ping":
                await ping(socket, info_message_objet, jid);
                break;
            case "num":
                await send_my_number(socket, info_message_objet, jid);
                break;
            case "date":
                await send_date(socket, info_message_objet, jid);
                break;
            case "gif":
                await send_media_from_store(
                    "gif",
                    socket,
                    info_message_objet,
                    jid,
                    args[0]
                );
                break;
            case "vid":
                await send_media_from_store(
                    "video",
                    socket,
                    info_message_objet,
                    jid,
                    args[0],
                    args[1],
                    args[2]
                );
                break;
            case "img":
                await send_media_from_store(
                    "image",
                    socket,
                    info_message_objet,
                    jid,
                    args[0],
                    args[1]
                );
                break;
            case "aud":
                await send_media_from_store(
                    "audio",
                    socket,
                    info_message_objet,
                    jid,
                    args[0],
                    args[1]
                );
                break;
            case "stk":
                await send_media_from_store(
                    "sticker",
                    socket,
                    info_message_objet,
                    jid,
                    args[0]
                );
                break;
            case "loc":
                await send_location_message(
                    socket,
                    info_message_objet,
                    jid,
                    args[0],
                    args[1],
                    args[2],
                    args[3]
                );
                break;
            case "contact":
                await send_contact(socket, info_message_objet, jid, args);
                break;
            case "react":
                await send_reaction_message(
                    socket,
                    info_message_objet,
                    jid,
                    args[0] || "👍"
                );
                break;
            case "vu":
                await vu_unique_visible(socket, info_message_objet, jid);
                break;
            case "store":
                await download_store(socket, info_message_objet, jid, args);
                break;
            case "tostk":
                await transform_to_sticker(socket, info_message_objet, jid);
                break;
            case "about":
                await send_text_message(
                    socket,
                    info_message_objet,
                    "> 🤖  Bot v2 deuxieme version public gratuite fais juste pour le fun dans mon temps libre  \nDéveloppé par [Vanscode ] soutenu par devAsk et Shadow  et inspirer de DevSenku ",
                    jid,
                    undefined,
                    true
                );
                break;
            case "isadmin":
                await verifie_admin(socket, info_message_objet, jid, isGroup, args[0]);
                break;
            case "promote":
                await promote(socket, info_message_objet, jid, isGroup);
                break;
            case "promoteall":
                await promoteall(socket, info_message_objet, jid, isGroup);
                break;
            case "demote":
                await demote(socket, info_message_objet, jid, isGroup);
                break;
            case "demoteall":
                await demoteall(socket, info_message_objet, jid, isGroup);
                break;
            case "ban":
                await ban(socket, info_message_objet, jid, isGroup);
                break;
            case "banall":
                await banall(socket, info_message_objet, jid, isGroup ,args[0]);
                break;
            case "mute":
                await mute(socket, info_message_objet, jid, isGroup, args[0]);
                break;
            case "unmute":
                await unmute(socket, info_message_objet, jid, isGroup);
                break;
            case "quote":
                const quote = await getQuote();
                await send_text_message(
                    socket,
                    info_message_objet,
                    quote,
                    jid,
                    undefined,
                    true
                );
                break;
            case "tagall":
                await tagall(socket, info_message_objet, jid, isGroup, args);
                break;
            case "stop":
                 stop_process();
                break;
            case "list":
                await liste_media(socket, info_message_objet, jid );
                break;
            case "doc":
                await documentation(socket, info_message_objet, jid,"mode_d_emploie.txt");
                break;
            case "welcome":
               await welcome(socket, info_message_objet, jid, isGroup, args[0]);
               break;
            case "setpp":
                await updateProfilePicture(socket, info_message_objet, jid);
                break;
            case "motivation":
                await send_reaction_message(socket, info_message_objet, jid, "💪");
                await send_video_message(socket, info_message_objet, jid, "media-bot/motivation.mp4","",true);
                break;
            case "updates":
                await send_reaction_message(socket, info_message_objet, jid, "🆕");
                await send_text_message(
                    socket,
                    info_message_objet,
                    "> 🆕 Dernières mises à jour :\n- Ajout de la commande (prefixe)motivation pour une dose d'énergie !\n- Amélioration de la gestion des médias stockés.\n- Optimisation des commandes d'administration.",
                    jid,
                    undefined,
                    true
                );
                break;
            case "info":
                await send_reaction_message(socket, info_message_objet, jid, "ℹ️");
                await getFullContactSummary(socket, info_message_objet, jid, args[0]);
                break;
                case "del":
                    await del_media(socket, info_message_objet, jid, args);
                    break;
                case "groupinfo":
                    await groupeinfo(socket, info_message_objet, jid, isGroup);
                    break;
            default:
                await send_reaction_message(socket, info_message_objet, jid, "❓");
                return 
        }
    } catch (error) {
        logger.error(`Erreur commande ${command}: ${error.message}`);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return;
    }
}

export function parseCommand(input) {
    if (!input?.startsWith(PREFIXE)) return null;

    const cleanInput = input.trim();
    const [command, ...args] = cleanInput.slice(PREFIXE.length).split(/\s+/);

    return {
        command: command.toLowerCase(),
        args: args.filter((arg) => arg.trim() !== ""),
    };
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Fonctions optimisées
const send_date = async (socket, info_message_objet, jid) => {
    const date = new Date().toLocaleString("fr-FR", {
        timeZone: "Africa/Douala",
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    });
    await send_reaction_message(socket, info_message_objet, jid, "📅");
    await send_text_message(
        socket,
        info_message_objet,
        `> 📅 ${date}`,
        jid,
        undefined,
        true
    );
};

const ping = async (socket, info_message_objet, jid) => {
    const start = Date.now();
    await send_reaction_message(socket, info_message_objet, jid, "📶");

    const latency = Date.now() - start;
    await send_text_message(
        socket,
        info_message_objet,
        `> 🏓 Pong! (${latency}ms)`,
        jid,
        undefined,
        true
    );

    await delay(2000);
    await send_reaction_message(socket, info_message_objet, jid, "");
};

const send_my_number = async (socket, info_message_objet, jid) => {
    const numero = socket.user.id.split(":")[0];
    await send_reaction_message(socket, info_message_objet, jid, "📱");
    await send_text_message(
        socket,
        info_message_objet,
        `> 📱 Votre numéro: ${numero}`,
        jid,
        undefined,
        true
    );
};

// Gestion média unifiée
async function send_media_from_store(
    type,
    socket,
    info_message_objet,
    jid,
    filename,
    vo = undefined,
    ptv = undefined
) {
    if (!filename) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Nom de fichier manquant!\nUsage: ${PREFIX}${type} <nom>`,
            jid
        );
    }

    const extensions = {
        image: ".jpg",
        video: ".mp4",
        audio: ".ogg",
        gif: ".mp4",
        sticker: ".webp",
    };

    const filePath = join(MEDIA_PATH, `${filename}_${type}${extensions[type]}`);

    if (!chercherFichier(filename, type, MEDIA_PATH)) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ ${type} "${filename}" introuvable!`,
            jid,
            undefined,
            true
        );
    }

    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");

        switch (type) {
            case "image":
                await send_image_message(
                    socket,
                    info_message_objet,
                    jid,
                    filePath,
                    undefined,
                    vo == "vo" ? true : false
                );
                break;
            case "video":
                await send_video_message(
                    socket,
                    info_message_objet,
                    jid,
                    filePath,
                    undefined,
                    ptv == "ptv" ? true : false,
                    vo == "vo" ? true : false
                );
                break;
            case "audio":
                await send_audio_message(
                    socket,
                    info_message_objet,
                    jid,
                    filePath,
                    undefined,
                    vo == "vo" ? true : false
                );
                break;
            case "gif":
                await send_gif_message(socket, info_message_objet, jid, filePath);
                break;
            case "sticker":
                await send_sticker_message(socket, info_message_objet, jid, filePath);
                break;
        }

        await send_reaction_message(socket, info_message_objet, jid, "✅");
    } catch (error) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        logger.error(`Erreur envoi ${type}: ${error.message}`);
    }
}

// Fonctions restantes optimisées
const vu_unique_visible = async (socket, info_message_objet, jid) => {
    if (
        !info_message_objet.message?.extendedTextMessage?.contextInfo?.quotedMessage
    ) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Répondez à un message 'view once'",
            jid,
            undefined,
            true
        );
    }

    try {
        await send_reaction_message(socket, info_message_objet, jid, "👁️");

        const quoted = {
            key: {
                remoteJid: info_message_objet.key.remoteJid,
                id: info_message_objet.message.extendedTextMessage.contextInfo.stanzaId,
                fromMe: false,
            },
            message:
                info_message_objet.message.extendedTextMessage.contextInfo
                    .quotedMessage,
        };

        const success = await downloader_media(socket, quoted, "oncevue");
        if (!success) throw new Error("Échec téléchargement");

        const media = await listerPremierFichierTemporaire(MEDIA_PATH, "oncevue");
        if (!media) throw new Error("Média introuvable");

        switch (media.type) {
            case "image":
                await send_image_message(
                    socket,
                    info_message_objet,
                    jid,
                    join(MEDIA_PATH, media.chemin)
                );
                break;
            case "video":
                await send_video_message(
                    socket,
                    info_message_objet,
                    jid,
                    join(MEDIA_PATH, media.chemin)
                );
                break;
            case "audio":
                await send_audio_message(
                    socket,
                    info_message_objet,
                    jid,
                    join(MEDIA_PATH, media.chemin)
                );
                break;
            case "gif":
                await send_gif_message(
                    socket,
                    info_message_objet,
                    jid,
                    join(MEDIA_PATH, media.chemin)
                );
                break;
            default:
                throw new Error(`Type non supporté: ${media.type}`);
        }

        await send_reaction_message(socket, info_message_objet, jid, "✅");
    } catch (error) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        logger.error(`Erreur vu_unique: ${error.message}`);
    } finally {
        supprimerFichierCommencantPar(MEDIA_PATH, "oncevue");
    }
};

const download_store = async (socket, info_message_objet, jid, args) => {
    if (!args[0]) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Usage: ${PREFIXE}store <nom>`,
            jid,
            undefined,
            true
        );
    }

    if (
        !info_message_objet.message?.extendedTextMessage?.contextInfo?.quotedMessage
    ) {
        conversation;
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Répondez à un média",
            jid,
            undefined,
            true
        );
    }
    if (
        info_message_objet.message?.extendedTextMessage?.contextInfo?.quotedMessage
            ?.conversation ||
        info_message_objet.message?.extendedTextMessage?.contextInfo?.quotedMessage
            ?.text
    ) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Répondez à un média pas un texte",
            jid,
            undefined,
            true
        );
    }

    try {
        await send_reaction_message(socket, info_message_objet, jid, "📥");

        const quoted = {
            key: {
                remoteJid: info_message_objet.key.remoteJid,
                id: info_message_objet.message.extendedTextMessage.contextInfo.stanzaId,
                fromMe: false,
            },
            message:
                info_message_objet.message.extendedTextMessage.contextInfo
                    .quotedMessage,
        };

        await downloader_media(socket, quoted, args[0]);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
    } catch (error) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        logger.error(`Erreur store: ${error.message}`);
    }
};

const send_contact = async (socket, info_message_objet, jid, args) => {
    if (!args[0] || !estNumeroTelephone(args[0])) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Numéro invalide!\nUsage: #contact <numéro> [nom]",
            jid,
            undefined,
            true
        );
    }

    try {
        await send_reaction_message(socket, info_message_objet, jid, "📇");
        await send_contact_message(
            socket,
            info_message_objet,
            jid,
            args[1] || "Contact",
            args[0]
        );
    } catch (error) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        logger.error(`Erreur contact: ${error.message}`);
    }
};

const transform_to_sticker = async (socket, info_message_objet, jid) => {
    if (
        !info_message_objet.message?.extendedTextMessage?.contextInfo?.quotedMessage
    ) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return send_text_message(
            socket,
            info_message_objet,
            "⚠️ Répondez à un média",
            jid,
            undefined,
            true
        );
    }

    try {
        await send_reaction_message(socket, info_message_objet, jid, "🔄");

        const quoted = {
            key: {
                remoteJid: info_message_objet.key.remoteJid,
                id: info_message_objet.message.extendedTextMessage.contextInfo.stanzaId,
                fromMe: false,
            },
            message:
                info_message_objet.message.extendedTextMessage.contextInfo
                    .quotedMessage,
        };

        const success = await downloader_media(socket, quoted, "tosticker");
        if (!success) throw new Error("Échec téléchargement");

        const media = await listerPremierFichierTemporaire(MEDIA_PATH, "tosticker");
        if (!media) throw new Error("Média introuvable");

        const inputPath = join(MEDIA_PATH, media.chemin);
        const outputPath = inputPath.replace(/\.[^.]+$/, ".webp");

        await convertToSticker(inputPath, outputPath);
        await send_sticker_message(socket, info_message_objet, jid, outputPath);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
    } catch (error) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        logger.error(`Erreur tostk: ${error.message}`);
    } finally {
        supprimerFichierCommencantPar(MEDIA_PATH, "tosticker");
    }
};

const verifie_admin = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Récupérer l'identifiant de l'utilisateur cible
    let userId =
        info_message_objet.message?.extendedTextMessage?.contextInfo?.participant;
    let typeuserid = userId.endsWith("@s.whatsapp.net");

    if (!userId) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Aucun identifiant trouvé ! Répondez à un message de la cible ",
            jid,
            undefined,
            true
        );
        return false;
    }

    if (typeuserid) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️vous ne pour pas faire d'action sur vous meme ou sur un de vos contact dans le groupe ",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 3. Vérifier le statut admin
    try {
        const estAdmin = await isAdmin(socket, jid, userId);
        if (!estAdmin) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                `> ⚠️ la cible ${userId} n'est pas admin du groupe !`,
                jid,
                undefined,
                true
            );
            return false;
        }

        await send_reaction_message(socket, info_message_objet, jid, "✅");
        await send_text_message(
            socket,
            info_message_objet,
            `> 🕵️‍♂️ la cible ${userId} est admin du groupe !`,
            jid,
            undefined,
            true
        );
        return userId;
    } catch (error) {
        console.error("Erreur lors de la vérification admin:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Erreur lors de la vérification du statut admin.",
            jid,
            undefined,
            true
        );
        return false;
    }
};

const promote = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Vérifier si le bot est admin

    const botlid = info_message_objet.key.participant;

    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas promouvoir car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 3. Récupérer l'utilisateur cible
    let userId =
        info_message_objet.message?.extendedTextMessage?.contextInfo?.participant;
    let typeuserid = userId?.endsWith("@s.whatsapp.net");
    if (!userId) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Aucun identifiant trouvé !, Répondez à un message de la cible ",
            jid,
            undefined,
            true
        );
        return false;
    }
    if (typeuserid) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️vous ne pour pas faire d'action sur vous meme ou sur un de vos contact dans le groupe ",
            jid,
            undefined,
            true
        );
        return false;
    }
    // 4. Tenter la promotion
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        if (await isAdmin(socket, jid, userId)) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ la cible  est déjà admin du groupe.",
                jid,
                undefined,
                true
            );
            return false;
        }
        await promoteAdmin(socket, jid, [userId]);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        return true;
    } catch (error) {
        console.error("Erreur promotion:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Échec de la promotion. Vérifiez que l'utilisateur est dans le groupe.",
            jid,
            undefined,
            true
        );
        return false;
    }
};
const promoteall = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }
    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;
    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas promouvoir car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }
    // 3. Récupérer la liste des participants
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        const groupMetadata = await socket.groupMetadata(jid);
        const participants = groupMetadata.participants;
        const nonAdmins = participants.filter((participant) => !participant.admin);
        if (nonAdmins.length === 0) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Aucun membre à promouvoir.",
                jid,
                undefined,
                true
            );
            return false;
        }
        const userIds = nonAdmins.map((participant) => participant.id);
        await promoteAdmin(socket, jid, userIds);
        await send_reaction_message(socket, info_message_objet, jid, "✅");

        return true;
    } catch (error) {
        console.error("Erreur promotion de tous les membres:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Échec de la promotion de tous les membres. Vérifiez que le bot est admin.",
            jid,
            undefined,
            true
        );
        return false;
    }
};

const demote = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;

    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas retrograder car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 3. Récupérer l'utilisateur cible
    let userId =
        info_message_objet.message?.extendedTextMessage?.contextInfo?.participant;
    let typeuserid = userId?.endsWith("@s.whatsapp.net");

    if (!userId) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Aucun identifiant trouvé ! Répondez à un message de la cible ",
            jid,
            undefined,
            true
        );
        return false;
    }
    if (typeuserid) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️vous ne pour pas faire d'action sur vous meme ou sur un de vos contact dans le groupe ",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 4. Tenter la rétrogradation
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        /*   if (!await isAdmin(socket, jid, userId)) {
                    await send_reaction_message(socket, info_message_objet, jid, '❌');
                    await send_text_message(
                        socket,
                        info_message_objet,
                        "> ⚠️ la cible  n'est pas admin du groupe.",
                        jid,
                        undefined,
                        true
                    );
                    return false;
                }*/
        await demoteAdmin(socket, jid, [userId]);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        return true;
    } catch (error) {
        console.error("Erreur rétrogradation:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Échec de la rétrogradation. Vérifiez que l'utilisateur est dans le groupe.",
            jid,
            undefined,
            true
        );
        return false;
    }
};
const demoteall = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }
    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;
    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas retrograder car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }
    // 3. Récupérer la liste des participants
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        const groupMetadata = await socket.groupMetadata(jid);
        const participants = groupMetadata.participants;
        const Admins = participants.filter(
            (participant) => participant.admin && participant.id !== botlid
        );
        if (Admins.length === 1) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Aucun membre à rétrograder.",
                jid,
                undefined,
                true
            );
            return false;
        }
        const userIds = Admins.map((participant) => participant.id);
        await demoteAdmin(socket, jid, userIds);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        return true;
    } catch (error) {
        console.error("Erreur rétrogradation de tous les membres:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Échec de la rétrogradation: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    }
};
const add = async (
    socket,
    info_message_objet,
    jid,
    isGroup,
    numero_telephone
) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;

    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "⚠️ vous ne pouvez pas ajouter car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 3. Vérifier le numéro de téléphone
    if (!numero_telephone || !estNumeroTelephone(numero_telephone)) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `⚠️ Numéro invalide !\nUsage: ${PREFIX}add <numéro>`,
            jid,
            undefined,
            true
        );
        return false;
    }
    // 4. Tenter l'ajout
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");

        // Convertir le numéro en JID WhatsApp
        const userJid = `${numero_telephone.replace(/\s+/g, "")}@s.whatsapp.net`;
        await addmember(socket, jid, [userJid]);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        await send_text_message(
            socket,
            info_message_objet,
            `✅ ${numero_telephone} a été ajouté au groupe.`,
            jid,
            undefined,
            true
        );
        return true;
    } catch (error) {
        console.error("Erreur ajout:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `⚠️ Échec de l'ajout: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    }
};
const ban = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;

    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas bannir  car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 3. Récupérer l'utilisateur cible
    let userId =
        info_message_objet.message?.extendedTextMessage?.contextInfo?.participant;
    let typeuserid = userId?.endsWith("@s.whatsapp.net");

    if (!userId) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Aucun identifiant trouvé ! Répondez à un message de la cible ",
            jid,
            undefined,
            true
        );
        return false;
    }
    if (typeuserid) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️vous ne pour pas faire d'action sur vous meme ou sur un de vos contact dans le groupe ",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 4. Tenter le bannissement
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");

        if (!(await isAdmin(socket, jid, userId))) {
            await banUser(socket, jid, [userId]);
            await send_reaction_message(socket, info_message_objet, jid, "✅");
            await send_text_message(
                socket,
                info_message_objet,
                `> 🚫 ${userId} a été banni du groupe.`,
                jid,
                undefined,
                true
            );
            return true;
        } else {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Vous ne pouvez pas bannir un administrateur.",
                jid,
                undefined,
                true
            );
            return false;
        }
    } catch (error) {
        console.error("Erreur bannissement:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Échec du bannissement: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    }
};
const banall = async (
    socket,
    info_message_objet,
    jid,
    isGroup,
    arg1 = undefined
) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }
    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;
    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas bannir car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }
    if (arg1 && arg1 !== "oneshot") {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> l'argument saisi n'est pas valide , voulez vous plutot dire 'oneshot' ? ",
            jid,
            undefined,
            true
        );
        return false;
    }
    // 3. Récupérer la liste des participants
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        const groupMetadata = await socket.groupMetadata(jid);
        const participants = groupMetadata.participants;
        const nonAdmins = participants.filter(
            (participant) => !participant.admin && participant.id !== botlid
        );
        if (nonAdmins.length === 0) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Aucun membre à bannir.",
                jid,
                undefined,
                true
            );
            return false;
        }
        const userIds = nonAdmins.map((participant) => participant.id);
        if (arg1 && arg1 === "oneshot") {
            flag=false;
            await banUser(socket, jid, userIds);
            flag=true;
        } else {
            await send_text_message(socket,info_message_objet,`> bannissement enclencher faite la commande ${PREFIXE}stop pour arreter le processus `,jid )
            for (const member of userIds) {
                if (!flag) break;
                await banUser(socket, jid, [member]);
                await sleep(1000)
            }
            flag=true
        }

        await send_reaction_message(socket, info_message_objet, jid, "✅");
        await send_text_message(
            socket,
            info_message_objet,
            `> 🚫 Tous les membres non admins ont été bannis.`,
            jid,
            undefined,
            true
        );
        await send_text_message(
            socket,
            info_message_objet,
            `> ${await getQuote()} `,
            jid,
            undefined,
            false
        );
        return true;
    } catch (error) {
        console.error("Erreur bannissement de tous les membres:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return false;
    }
};
const stop_process= (socket,info_message_objet,jid)=>{
    flag=false
    send_reaction_message(socket,info_message_objet,jid,"✔")
    
}
const mute = async (socket, info_message_objet, jid, isGroup, minute) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;

    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas mettre en sourdine car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }
    if (minute && (isNaN(minute) || minute < 1)) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Durée invalide !\nUsage: ${PREFIXE}mute <minutes>`,
            jid,
            undefined,
            true
        );
        return false;
    }

    // 3. Tenter de mettre en sourdine le groupe
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        await muteGroup(socket, jid, minute);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        if (minute) {
            await send_text_message(
                socket,
                info_message_objet,
                `> 🔕 Le groupe a été mis en sourdine pour ${minute} minute(s).`,
                jid,
                undefined,
                true
            );
        } else {
            await send_text_message(
                socket,
                info_message_objet,
                "> 🔕 Le groupe a été mis en sourdine indéfiniment.",
                jid,
                undefined,
                true
            );
        }
        return true;
    } catch (error) {
        console.error("Erreur mise en sourdine:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Échec de la mise en sourdine: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    }
};
const unmute = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Vérifier si le bot est admin
    const botlid = info_message_objet.key.participant;

    if (!(await isAdmin(socket, jid, botlid))) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ vous ne pouvez pas desactiver la sourdine car vous n'etes pas admin du groupe !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 3. Tenter de désactiver la sourdine du groupe
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        await unmuteGroup(socket, jid);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        return true;
    } catch (error) {
        console.error("Erreur désactivation sourdine:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        return false;
    }
};
const tagall = async (
    socket,
    info_message_objet,
    jid,
    isGroup,
    text = undefined
) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

    // 2. Récupérer la liste des participants
    try {
        const groupMetadata = await socket.groupMetadata(jid);
        const namegroup = groupMetadata.subject;
        const participants = groupMetadata.participants;
       // console.log(`participants dans le groupe: ${JSON.stringify(participants, null, 2)}`);
        

        if (participants.length === 0) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Aucun membre dans le groupe.",
                jid,
                undefined,
                true
            );
            return false;
        }

        // Construire le message de mention
        const mentions = participants.map((participant) => ({
            id: participant.id,
            displayName: participant.notify ||  participant.id.split("@")[0],
            
        }));

        const mentionText = mentions
            .map((m, i) => `${i + 1}. @${m.displayName}`)
            .join("\n");

        let message = `> 📢 Mention à tous les membres du groupe: ${namegroup}\n \n${mentionText}\n \n> Powered by Vanscode `;
        if (text && text.length > 0) {
            message = text.join(" ");
        }
        // Envoyer le message avec mentions
       /* await send_text_message(
            socket,
            info_message_objet,
            message,
            jid,
            mentions.map((m) => m.id),
            true,
            false
        );*/
       await socket.sendMessage(jid, {
            text: message,
            mentions: mentions.map((m) => m.id),

        });
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        return true;
    } catch (error) {
        console.error("Erreur tagall:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Échec de la mention: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    }
};
const liste_media=async(socket,info_message_objet,jid)=>{
    await send_reaction_message(socket, info_message_objet, jid, "⏳");
    const liste = await listerMedias("whatsapp-media")
    
    if (!liste) {
        await send_text_message(socket,info_message_objet,"Aucun media enregistrer ",jid,undefined,true);
         await send_reaction_message(socket, info_message_objet, jid, "❌");
    }else{
        await send_text_message(socket, info_message_objet, liste ,jid, undefined, true)
         await send_reaction_message(socket, info_message_objet, jid, "✔");
    }
}

const documentation=async(socket,info_message_objet,jid,path_file_txt)=>{
fs.readFile(path_file_txt, 'utf8', async (err, data) => {
    if (err) {
        console.error("Erreur lors de la lecture du fichier :", err);
        return;
    }
    await send_text_message(socket,info_message_objet,data,jid,undefined,true)
});
}


const welcome = async (socket, info_message_objet, jid, isGroup,argument) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }

   if (argument && argument.startsWith("off")) {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        const welcomeManager = getWelcomeManager(socket);
        try {
            await welcomeManager.disableForGroup(jid);
            await send_reaction_message(socket, info_message_objet, jid, "✅");
            await send_text_message(
                socket,
                info_message_objet,
                "> 🎉 Les messages de bienvenue et de depart ont été désactivés pour ce groupe.",
                jid,
                undefined,
                true
            );
        } catch (error) {
            console.error("Erreur désactivation des messages de bienvenue et depart :", error);
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                `> ⚠️ Échec de la désactivation des messages de bienvenue: ${error.message}`,
                jid,
                undefined,
                true
            );
        }
        return true;
    }
   
   if (argument && argument.startsWith("state")) {

        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        const welcomeManager = getWelcomeManager(socket);
        try {
            const state = await welcomeManager.isActive(jid);
            await send_reaction_message(socket, info_message_objet, jid, "✅");
            await send_text_message(
                socket,
                info_message_objet,
                `> 🎉 Les messages de bienvenue et de depart sont actuellement ${state ? "activés" : "désactivés"} pour ce groupe.`,
                jid,
                undefined,
                true
            );
        } catch (error) {
            console.error("Erreur vérification état des messages de bienvenue et depart :", error);
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                `> ⚠️ Échec de la vérification de l'état des messages de bienvenue: ${error.message}`,
                jid,
                undefined,
                true
            );
        }
        return true;
   }
 

    // 3. Tenter d'activer les messages de bienvenue
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        const welcomeManager = getWelcomeManager(socket);
        await welcomeManager.enableForGroup(jid);
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        await send_text_message(
            socket,
            info_message_objet,
            "> 🎉 Les messages de bienvenue et de depart  ont été activés pour ce groupe.",
            jid,
            undefined,
            true
        );
        return true;
    } catch (error) {
        console.error("Erreur activation des messages de bienvenue et depart :", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Échec de l'activation des messages de bienvenue: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    }
}

async function updateProfilePicture(socket,info_message_objet,jid) {
  if (
        !info_message_objet.message?.extendedTextMessage?.contextInfo?.quotedMessage
    ) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Veuillez répondre à une image pour mettre à jour la photo de profil.",
            jid,
            undefined,
            true
        );
        return false;
    }
    const quotedMessage = info_message_objet.message.extendedTextMessage.contextInfo.quotedMessage;
    if (!quotedMessage.imageMessage) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Le message cité n'est pas une image.",
            jid,
            undefined,
            true
        );
        return false;
    }
    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
         const quoted = {
            key: {
                remoteJid: info_message_objet.key.remoteJid,
                id: info_message_objet.message.extendedTextMessage.contextInfo.stanzaId,
                fromMe: false,
            },
            message:
                info_message_objet.message.extendedTextMessage.contextInfo
                    .quotedMessage,
        };
     const success = await downloader_media(socket, quoted, "profilppvans");
        if (!success) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Échec du téléchargement de l'image.",
                jid,
                undefined,
                true
            );
            return false;
        }
        const media = await listerPremierFichierTemporaire(MEDIA_PATH, "profilppvans");
        if (!media) {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Aucune image trouvée pour la mise à jour.",
                jid,
                undefined,
                true
            );
            return false;
        }
        if(media.type !== "image") {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Le fichier n'est pas une image valide.",
                jid,
                undefined,
                true
            );
            return false;
        }
        const imagePath =  join(MEDIA_PATH, media.chemin)      // 1. Vérifier que le fichier existe
        if (!fs.existsSync(imagePath)) {
            throw new Error("Le fichier image n'existe pas");
        }
          // 2. Lire et optimiser l'image
        const optimizedBuffer = await sharp(imagePath)
            .resize(500, 500) // Taille recommandée
            .jpeg({ quality: 85 }) // Format optimal pour WhatsApp
            .toBuffer();

        // 3. Mettre à jour la PP
        await socket.updateProfilePicture(socket.user.id, optimizedBuffer);
        
        await send_reaction_message(socket, info_message_objet, jid, "✅");
        await send_text_message(
            socket,
            info_message_objet,
            "> 📸 Photo de profil mise à jour avec succès.",
            jid,
            undefined,
            true
        );
        return true;
    } catch (error) {
        console.error("Erreur mise à jour de la photo de profil:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Échec de la mise à jour de la photo de profil: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    } finally {
        supprimerFichierCommencantPar(MEDIA_PATH, "profilppvans");
    }


    
}

async function getFullContactSummary(socket,info_message_objet,jid,phoneNumber ) {
    // Vérification du format du numéro
    if (!phoneNumber || !/^\+?[0-9\s]+$/.test(phoneNumber)) {
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Numéro de téléphone invalide ! Veuillez fournir un numéro valide.",
            jid,
            undefined,
            true)
        throw new Error("Numéro de téléphone invalide. Veuillez fournir un numéro valide.");
      
    }

    // Initialisation du résumé
    let summary = `📝 Rapport complet pour le numéro: ${phoneNumber}\n\n`;
    const startTime = Date.now();

    try {
        // Nettoyage du numéro
        const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
        const jid_user = `${cleanNumber}@s.whatsapp.net`;
        const normalizedJid = jidNormalizedUser(jid_user);

        // 1. Vérification présence sur WhatsApp
        summary += "🔍 Vérification présence sur WhatsApp...\n";
        const onWhatsApp = await socket.onWhatsApp(normalizedJid);
        
        if (!onWhatsApp || !onWhatsApp[0]?.exists) {
            summary += `❌ Le numéro ${cleanNumber} n'est pas inscrit sur WhatsApp\n`;
            summary += `⏱ Temps d'exécution: ${(Date.now() - startTime)/1000}s\n`;
            return summary;
        }
        
        summary += `✅ Trouvé sur WhatsApp (JID: ${normalizedJid})\n\n`;

        // 2. Récupération des informations de base
        summary += "📋 Récupération des informations de base...\n";
        const [contact, profilePicture, status, businessProfile, blocklist] = await Promise.all([
            socket.fetchStatus(normalizedJid).catch(() => null),
            socket.profilePictureUrl(normalizedJid, 'image').catch(() => null),
            socket.fetchStatus(normalizedJid).catch(() => null),
            socket.getBusinessProfile(normalizedJid).catch(() => null),
            socket.fetchBlocklist().catch(() => [])
        ]);

        // Ajout des infos de base au résumé
        const contactName = await getUserName(socket,phoneNumber);
        summary += `👤 Nom: ${contactName}\n`;
        summary += `🖼� Photo de profil: ${profilePicture ? "Disponible" : "Non disponible"}\n`;
        summary += `📌 Statut: ${status?.status || "Aucun"}\n`;
        if (status?.status) {
            const statusDate = new Date(status.setAt * 1000).toLocaleString();
            summary += `   ↳ Posté le: ${statusDate}\n`;
        }
        summary += `👀 Dernière connexion: ${contact?.lastSeen ? new Date(contact.lastSeen * 1000).toLocaleString() : "Inconnue"}\n`;
        summary += `✅ Compte vérifié: ${contact?.verified ? "Oui" : "Non"}\n`;
        summary += `🚫 Bloqué: ${blocklist.includes(normalizedJid) ? "Oui" : "Non"}\n\n`;

        // 3. Informations business si disponible
        if (businessProfile) {
            summary += "🏢 INFORMATIONS PROFESSIONNELLES:\n";
            summary += `📇 Description: ${businessProfile.description || "Aucune"}\n`;
            summary += `🏠 Adresse: ${businessProfile.address || "Non renseignée"}\n`;
            summary += `📧 Email: ${businessProfile.email || "Non renseigné"}\n`;
            summary += `🌐 Site web: ${businessProfile.website || "Non renseigné"}\n`;
            
            if (businessProfile.categories?.length > 0) {
                const categories = businessProfile.categories.map(c => c.name).join(", ");
                summary += `🏷 Catégories: ${categories}\n`;
            }
            
            if (businessProfile.business_hours) {
                summary += "🕒 Heures d'ouverture:\n";
                for (const [day, hours] of Object.entries(businessProfile.business_hours)) {
                    summary += `   - ${day}: ${hours.open || "Fermé"}\n`;
                }
            }
            summary += "\n";
        }

        // 4. Groupes en commun (optionnel - peut être long)
        summary += "👥 Recherche de groupes en commun... (cela peut prendre du temps)\n";
        try {
            const groups = await socket.groupFetchAllParticipating();
            const commonGroups = Object.values(groups)
                .filter(g => g.participants.some(p => p.id === normalizedJid))
                .map(g => ({
                    id: g.id,
                    subject: g.subject,
                    creation: new Date(g.creation * 1000).toLocaleDateString(),
                    owner: g.owner
                }));

            if (commonGroups.length > 0) {
                summary += `✅ Vous avez ${commonGroups.length} groupe(s) en commun:\n`;
                commonGroups.forEach((group, index) => {
                    summary += `   ${index + 1}. ${group.subject} (Créé le ${group.creation})\n`;
                });
            } else {
                summary += "ℹ️ Aucun groupe en commun trouvé\n";
            }
        } catch (e) {
            summary += "⚠️ Impossible de récupérer les groupes en commun\n";
        }

        // 5. Informations supplémentaires
        summary += "\n🔍 INFORMATIONS COMPLÉMENTAIRES:\n";
        summary += `📱 Type de compte: ${businessProfile ? "Business" : "Standard"}\n`;
        summary += `🕒 Heure locale estimée: ${new Date().toLocaleString()}\n`;
        summary += `⏱ Temps d'analyse: ${(Date.now() - startTime)/1000} secondes\n`;
        
        if (profilePicture) {
           const ppBuffer = await getProfilePictureFromPhoneNumber(socket,jid,phoneNumber);
          return  await socket.sendMessage(jid, {
                image: ppBuffer,
                caption: summary,
            });
        }else {
          return   await send_text_message(
                socket,
                info_message_objet,
                summary,
                jid,
                undefined,
                true
            );
        }

    } catch (error) {
        summary += "\n❌ ERREUR LORS DE L'ANALYSE:\n";
        summary += `Message: ${error.message}\n`;
        summary += `Stack: ${error.stack || "Non disponible"}\n`;
        summary += `⏱ Temps écoulé: ${(Date.now() - startTime)/1000}s\n`;
        return summary;
    }
}

const del_media = async (socket, info_message_objet, jid, arg) => {
 if (!arg || arg.length === 0) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Veuillez spécifier le nom  du média à supprimer  (image, video, audio,gif,sticker).",
            jid,
            undefined,
            true
        );
        return false;
    }
    const name = arg[0];
    const type = arg[1] ? arg[1].toLowerCase() : null;
    if (!type) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Veuillez spécifier  le type de média à supprimer (image, video, audio,gif,sticker).",
            jid,
            undefined,
            true
        );
        return false;
    }
    const validTypes = ["image", "video", "audio","gif","sticker"];
    if (!validTypes.includes(type)) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Type de média invalide !\nTypes valides: ${validTypes.join(", ")}`,
            jid,
            undefined,
            true
        );
        return false;
    }

    try {
        await send_reaction_message(socket, info_message_objet, jid, "⏳");
        const success =await supprimerFichierCommencantPar(MEDIA_PATH, `${name}_${type}`);
        if (success) {
            await send_reaction_message(socket, info_message_objet, jid, "✅");
            await send_text_message(
                socket,
                info_message_objet,
                `> 🗑️ Média ${name} de type ${type} supprimé avec succès.`,
                jid,
                undefined,
                true
            );
            return true;
        } else {
            await send_reaction_message(socket, info_message_objet, jid, "❌");
            await send_text_message(
                socket,
                info_message_objet,
                `> ⚠️ Aucune média trouvé avec le nom ${name} et le type ${type}.`,
                jid,
                undefined,
                true
            );
            return false;
        }
    } catch (error) {
        console.error("Erreur suppression média:", error);
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            `> ⚠️ Échec de la suppression du média: ${error.message}`,
            jid,
            undefined,
            true
        );
        return false;
    }
};



 
    
const  getProfilePictureFromPhoneNumber =async(socket,jid,phoneNumber)=> {
    try {
        // Formater le numéro en JID (ex: 1234567890 → 1234567890@s.whatsapp.net)
        const ciblejid = `${phoneNumber}@s.whatsapp.net`;
        const ppUrl = await socket.profilePictureUrl(ciblejid, 'image');
        
        if (!ppUrl) {
            console.log("[PP Fetch] Aucune photo de profil trouvée ou paramètres de confidentialité bloquants");
            await send_text_message(
                socket,
                info_message_objet,
                "> ⚠️ Aucune photo de profil trouvée ou paramètres de confidentialité bloquants",
                jid,
                undefined,
                true
            );
            return null;
        }
        const response = await fetch(ppUrl);
        return Buffer.from(await response.arrayBuffer());
    } catch (error) {
        console.error("[PP Fetch Error]", error);
        return null;
    }
}

async function getUserName(socket,phoneNumber) {
    const jid = `${phoneNumber}@s.whatsapp.net`;
    
    try {
        // 1. Essayer de récupérer depuis les contacts
        const contact = await socket.contacts?.get(jid);
        if (contact?.name || contact?.notify) {
            return contact.name || contact.notify;
        }

        // 2. Essayer via les infos du groupe (si disponible)
        const chats = await socket.chats?.fetch();
        const chat = chats?.find(c => c.id === jid || c.conversation.includes(phoneNumber));
        if (chat?.name) return chat.name;

        // 3. Essayer via le profil
        const profile = await socket.profilePictureUrl(jid, 'preview');
        if (profile?.name) return profile.name;

        // 4. Retourner le numéro si rien trouvé
        return phoneNumber;
    } catch (error) {
        console.error("Erreur lors de la récupération du nom:", error);
        return phoneNumber; // Fallback au numéro
    }
}
 const groupeinfo = async (socket, info_message_objet, jid, isGroup) => {
    // 1. Vérifier si c'est un groupe
    if (!isGroup) {
        await send_reaction_message(socket, info_message_objet, jid, "❌");
        await send_text_message(
            socket,
            info_message_objet,
            "> ⚠️ Cette commande est réservée aux groupes WhatsApp !",
            jid,
            undefined,
            true
        );
        return false;
    }
   await send_reaction_message(socket, info_message_objet, jid, "⏳");
   const informations= await analyserGroupeWhatsApp(socket,jid) ;
    await socket.sendMessage(jid, {
        text: informations.rapport,
        mentions: [informations.owner],
    });
    await send_reaction_message(socket, info_message_objet, jid, "✅");
    return true;
};
   