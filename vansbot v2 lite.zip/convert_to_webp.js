import sharp from 'sharp';
import { promises as fs } from 'fs';
export async function convertToSticker(inputPath, outputPath) {
    await sharp(inputPath)
        .resize(512, 512) // WhatsApp recommande 512x512
        .toFormat('webp')
        .toFile(outputPath);
    await fs.unlink(inputPath); // Supprimer le fichier original après conversion
}

//convertToSticker('input.png', 'output.webp');