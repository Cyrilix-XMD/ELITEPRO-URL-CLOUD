
<?php

require admin_view('access');