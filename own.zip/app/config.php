<?php
				

				
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://noorsmmpanel.in' );
define('STYLESHEETS_URL', '//noorsmmpanel.in' );
error_reporting(1);
date_default_timezone_set('Asia/Kolkata');

return [
  'db' => [
    'name'    =>  'fastpxch_noorsmmpanel' ,
    'host'    =>  'localhost',
    'user'    =>  'fastpxch_noorsmmpanel' ,
    'pass'    =>  'b+[t$;^EmZ}*' ,
    'charset' =>  'utf8mb4' 
  ]
];

?>