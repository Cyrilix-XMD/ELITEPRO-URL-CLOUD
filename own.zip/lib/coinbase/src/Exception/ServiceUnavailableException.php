<?php

namespace Coinbase\Wallet\Exception;

class ServiceUnavailableException extends HttpException
{
}
