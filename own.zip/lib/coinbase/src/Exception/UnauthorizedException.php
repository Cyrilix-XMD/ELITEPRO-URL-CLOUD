<?php

namespace Coinbase\Wallet\Exception;

class UnauthorizedException extends HttpException
{
}
