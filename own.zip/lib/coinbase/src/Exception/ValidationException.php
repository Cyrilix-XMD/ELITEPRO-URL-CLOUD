<?php

namespace Coinbase\Wallet\Exception;

class ValidationException extends HttpException
{
}
