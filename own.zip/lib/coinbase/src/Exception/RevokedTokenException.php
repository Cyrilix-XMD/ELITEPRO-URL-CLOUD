<?php

namespace Coinbase\Wallet\Exception;

class RevokedTokenException extends UnauthorizedException
{
}
