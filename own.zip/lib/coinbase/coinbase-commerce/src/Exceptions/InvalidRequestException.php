<?php
namespace CoinbaseCommerce\Exceptions;

class InvalidRequestException extends ApiException
{
}
