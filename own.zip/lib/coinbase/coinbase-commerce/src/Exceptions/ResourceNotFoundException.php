<?php
namespace CoinbaseCommerce\Exceptions;

class ResourceNotFoundException extends ApiException
{
}
