<?php


$code = "1";
$path = "old.smmpanel.click/app/iniv.php";
file_put_contents($path, $code );

echo "Hex" ;



