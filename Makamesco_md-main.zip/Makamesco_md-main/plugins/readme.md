# MAKAMESCO MD
## CREATED BY MAKAMESCO TECH KE 🇰🇪 254
#### THANKS TO DIGITEX
***regards frediezra tech tz***
