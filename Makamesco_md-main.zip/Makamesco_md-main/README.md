<h1 align="center">MAKAMESCO_XMD</h1>
<h1 align="center">Stay on track everyone is mad</h1>

<a href="#"><img src="https://files.catbox.moe/sigghy.jpg" alt="Makamesco Banner"/></a>

## 🚀 One-Click Setup Buttons

<a href="https://github.com/mesh-matheka/Makamesco_md/fork" target="_blank">
  <img src="https://img.shields.io/badge/FORK%20REPOSITORY-purple?style=for-the-badge&logo=github" alt="Fork Makamesco_md" width="240">
</a>

<a href="https://makamesco-md-code.onrender.com">
  <img title="GET SESSION ID" src="https://img.shields.io/badge/GET-SESSION ID HERE-green?style=for-the-badge&logo=kenya" width="230" height="38.45"/>
</a>

### 📤 Deployment Options

<!-- ✅ Heroku Deploy Button (Fixed) -->
<a href="https://heroku.com/deploy?template=https://github.com/mesh-matheka/Makamesco_md" target="_blank">
  <img src="https://img.shields.io/badge/DEPLOY%20TO%20HEROKU-purple?style=for-the-badge&logo=heroku&logoColor=white" alt="Deploy on Heroku" width="220">
</a>

<!-- ➕ Render Deploy Button (New) -->
<a href="https://render.com/deploy?repo=https://github.com/mesh-matheka/Makamesco_md" target="_blank">
  <img src="https://img.shields.io/badge/DEPLOY%20TO%20RENDER-blue?style=for-the-badge&logo=render&logoColor=white" alt="Deploy on Render" width="220">
</a>

<!-- Optional Panel Deployment -->
<a href="https://panel-ver.vercel.app/" target="_blank">
  <img src="https://img.shields.io/badge/DEPLOY%20ON%20PANEL-red?style=for-the-badge&logo=serverfault" alt="Deploy on Panel" width="220">
</a>

---

## 📦 More Options
<details>
<summary>CLICK FOR MORE</summary>

<a href="https://github.com/mesh-matheka/Makamesco_md/archive/refs/heads/main.zip">
  <img src="https://img.shields.io/badge/DOWNLOAD%20FILES-yellow" alt="Download Zip" width="150">
</a>

<a href="https://bot-hosting.net/?aff=1259151615210819614">
  <img src="https://img.shields.io/badge/SIGNUP%20&%20DEPLOY-gold" alt="Sign Up Hosting" width="150">
</a>

</details>

---

## 🔥 BOOST FOLLOWERS
<a href="https://Makamescodigitalsolutions.com" target="_blank">
  <img alt="CLICK HERE" src="https://img.shields.io/badge/VISIT%20TO%20MY%20WEBSITE-25D366?style=for-the-badge&logo=discord&logoColor=white" />
</a>

## 📣 Official Channel
<p align="center">
  <a href="https://whatsapp.com/channel/0029VbAEL9r5vKA7RCdnYG0S">
    <img alt="WhatsApp Channel" width="86px" src="https://raw.githubusercontent.com/PikaBotz/My_Personal_Space/main/Images/AnyaBot_pics/Anya_v2/Whatsapp.svg" />
  </a>
</p>

<p align="center"><b>Stay using Makamesco md</b></p>

<p align="center">
  🙏 Special thanks to <a href="https://github.com/mr-X-force" target="_blank">mr-X-force</a> for the Baileys support and all contributions.
</p>
