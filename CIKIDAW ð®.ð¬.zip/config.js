module.exports = {
  BOT_TOKEN: "7770986579:AAERChdZaMX7fj87o57_XDs5VzrVe_t-TGU",
};