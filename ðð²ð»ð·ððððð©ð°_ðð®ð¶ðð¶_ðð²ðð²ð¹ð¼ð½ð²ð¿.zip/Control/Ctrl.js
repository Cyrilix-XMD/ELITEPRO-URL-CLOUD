// Module
const fs = require('fs')

//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = true // True For Public // False For Self
global.owner = ['6285727819741'] //Own Number
global.developer = "𝐀𝐥𝐰𝐚𝐲𝐬𝐊𝐚𝐢𝐳𝐢" //Dev Name
global.botname = "𝐏𝐚𝐫𝐚𝐝𝐨𝐱𝐓𝐞𝐚𝐦" //Bot Name
global.version = "2.0.0" //Version Bot
global.own = "𝐎𝐰𝐧" // Ganti Nomer Mu
global.noOwn = "628737894097"

//Payment Lu
global.dana = "08645589397"//no dana lu
global.gopay = "0877764528207"//no gopay lu
global.ovo = "0837373774"//no ovo lu 
global.qris = "link qris"//jadiin link qris mu


global.packname = "Sticker By" //Pack Name 
global.author = "𝐏𝐚𝐫𝐚𝐝𝐨𝐱𝐓𝐞𝐚𝐦" // Author

//Social Media Settings
global.ytube = "https://youtube.com/@"
global.ttok = "https://tiktok.com/@"
global.igram = "https://instagram.com/@"
global.chtele = "https://t.me/tamaryuichicrasher"
global.tgram = "https://t.me/"

//Bug Name Settings
global.bak = {
Ios: " ⿻ᬃ𝐏𝐚𝐫𝐚𝐝𝐨𝐱𝐊𝐢𝐥𝐥𝐘𝐨𝐮⃟⃟⿻ ",
Andro: "⩟⬦𪲁 𝐊𝐚𝐢𝐳𝐢𝐊𝐢𝐥𝐥𝐘𝐨𝐮̸̷̷̷͡𝐗͜͢𝐒 -", 
Crash: " ̶C̶r̶a̶s̶h̶U̶l̶t̶i̶m̶a̶̶t̶e ̶",
Freeze: "𝐏𝐚𝐫𝐚𝐝𝐨𝐱𝐔𝐥𝐭𝐢𝐦𝐚𝐭𝐞",
Ui: "ℭ𝔯𝔴𝔰𝔥 𝔘𝔦 𝔖𝔶𝔰𝔱𝔢𝔪"
}

//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})