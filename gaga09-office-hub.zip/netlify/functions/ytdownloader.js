const ytdl = require('ytdl-core');

exports.handler = async (event) => {
  const { url } = JSON.parse(event.body);

  if (!ytdl.validateURL(url)) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Invalid YouTube URL' })
    };
  }

  const info = await ytdl.getInfo(url);
  const format = ytdl.chooseFormat(info.formats, { quality: 'highest' });

  return {
    statusCode: 200,
    body: JSON.stringify({ downloadUrl: format.url, title: info.videoDetails.title })
  };
};
