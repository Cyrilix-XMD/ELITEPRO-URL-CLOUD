const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

exports.handler = async (event) => {
  const { prompt } = JSON.parse(event.body);

  const response = await openai.createCompletion({
    model: "gpt-3.5-turbo-instruct",
    prompt,
    max_tokens: 500,
  });

  return {
    statusCode: 200,
    body: JSON.stringify({ result: response.data.choices[0].text }),
  };
};
